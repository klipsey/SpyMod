# 1.0.0

- Added proper emote compat
- Added VFX for killstreaks with the big earner
- Added Monsoon Skin which comes with unique killstreak vfx
- Fixed the knife model having 100,000 verts
- Added unlock achievement
- New Icon

# 0.7.1

- Fixed head floating forever

# 0.7.0

- Added new ability The Ambassador

- Added new ability The Big Earner

- Added new ability Cloak

- Deadmans Watch swapped with Cloak as the alt

- New cloak vfx

- New sfx

- Networked

- Deadmans watch now caps damage taken instead of forcing the max amount

- Sapper is more accurate

# 0.6.3

- I broke stuff again but it should be fixed now
- Nerfed sapper

# 0.6.2

- Fixed hard crash...

# 0.6.1

- ReadMe and bug fixes

# 0.6.0

- Flip is now Sap
- Sap allows you to dash in 4 different directions + flip and attaches a sapper to the nearest enemy
- Revolver is now The Diamondback giving you crits for knife kills
- UI for Diamondback
- QOL changes for cloak
- Sfx and Vfx additions
- Animation polish
- Knife damage balancing

# 0.5.1

- Read me fix

# 0.5.0

- Spy released!