# 0.6.0

- Flip is now Sap
- Sap allows you to dash in 4 different directions + flip and attaches a sapper to the nearest enemy
- Revolver is now The Diamondback giving you crits for knife kills
- UI for Diamondback
- QOL changes for cloak
- Sfx and Vfx additions
- Animation polish
- Knife damage balancing

# 0.5.1

- Read me fix

# 0.5.0

- Spy released!