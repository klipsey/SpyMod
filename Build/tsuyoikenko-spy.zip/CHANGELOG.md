# 0.5.1

- Read me fix

# 0.5.0

- Spy released!