# 1.2.0

- Sots update
- Re added spies execute. 500% damage on backstab + crit, below 20% hp execute

# 1.1.8 

- Networked sap and big earner stab
- Changed backstab damage to be 5x damage + crit

# 1.1.7

- Maybe fixed sound?????

# 1.1.6

- Removed scoliosis
- Fixed exploits and bugs

# 1.1.5

- Networking

# 1.1.4

- Actually checked to see if last update worked lol

# 1.1.3

- Hopefully fixed primary and secondary alts being always highlighted

# 1.1.2

- Added Ancient Scepter support for Cloak and Deadman's Watch
- Fixed the 0.25 proc coefficient being on the self damage for spy instead of his knife 

# 1.1.1

- Hopefully fixed spy backstab cloak bug
- Removed unlock condition for now

# 1.1.0

- Stealth sound fixed

# 1.0.9

- Oops

# 1.0.8

- Nerfed ambassador base damage
- Backstab's execute has a 0.25 proc coefficient instead of none
- Hopefully fixed backstabs not counting in multiplayer for the unlock
- Ambassador animation and sound fix

# 1.0.7

- Diamondback now gains 3 crits on normal enemies and 5 on elites+
- Backstabs now do a miniumum of 10% max health damage to bosses
- Fixed token for ambassador
- Fixed anim for ambassador

# 1.0.6

- Accidently removed Spy's ability to backstab  LMAO

# 1.0.5

- Fixed the stupid anims breaking when attacking with knife or shooting

# 1.0.4

- Decreased Cloak armor but gave it movement speed
- Hopefully fixed Big Earner not resetting on kill
- Item displays!

# 1.0.3

- Configs
- Fixed deadringer being your entire hp bar worth of damage
- Reverted Ambassador changes to crit again (damage falloff still persists)
- Added Ragdoll Decoy

# 1.0.2

- Token cleanup
- Walk and Sprint cleanup 

# 1.0.1

- Spy no longer looks like he's crankin one out while sprinting
- Added damage falloff to The Ambassador and remove the 100% crit chance on headshot for 2x damage instead
- Buffed big earner and the diamondback to work on bosses without kills (no reset for big earner on hit)

# 1.0.0

- Added proper emote compat
- Added VFX for killstreaks with the big earner
- Added Monsoon Skin which comes with unique killstreak vfx
- Fixed the knife model having 100,000 verts
- Added unlock achievement
- New Icon

# 0.7.1

- Fixed head floating forever

# 0.7.0

- Added new ability The Ambassador

- Added new ability The Big Earner

- Added new ability Cloak

- Deadmans Watch swapped with Cloak as the alt

- New cloak vfx

- New sfx

- Networked

- Deadmans watch now caps damage taken instead of forcing the max amount

- Sapper is more accurate

# 0.6.3

- I broke stuff again but it should be fixed now
- Nerfed sapper

# 0.6.2

- Fixed hard crash...

# 0.6.1

- ReadMe and bug fixes

# 0.6.0

- Flip is now Sap
- Sap allows you to dash in 4 different directions + flip and attaches a sapper to the nearest enemy
- Revolver is now The Diamondback giving you crits for knife kills
- UI for Diamondback
- QOL changes for cloak
- Sfx and Vfx additions
- Animation polish
- Knife damage balancing

# 0.5.1

- Read me fix

# 0.5.0

- Spy released!